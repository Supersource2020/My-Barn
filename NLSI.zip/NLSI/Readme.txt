%   This code is offered only for reserch purpose.
%   If you use this code for a potential publication, please cite the following paper:
% 
%   S. Y. Zhu, B. Zeng, L.Y. Zeng and M. Gabbouj, 
%��Image interpolation based on non-local geometric similarities and directional gradients,�� 
%   IEEE Transactions on Multimedia. vol. 18, no. 9, pp. 1707-1719, Sept. 2016. 

% 1. Using Main_NLSI(file) to implement the non-local similarity based interpolation.

% 2. The resolution of the input image is NxN and  the resolution of the output image is NxN.

% 3.  If the input is the gray-level image, the output is the gray-level image, where the PSNR is calculated with the
% double format data.

% 4. If the input is the RGB-color image, the output is the RGB-color image, where  the PSNR is calculated based on the % average PSNR value of three color channels.