%   This code is offered only for reserch purpose.
%   If you use this code for a potential publication, please cite the following paper:
% 
%   S. Y. Zhu, B. Zeng, L.Y. Zeng and M. Gabbouj, 
%��Image interpolation based on non-local geometric similarities and directional gradients,�� 
%   IEEE Transactions on Multimedia. vol. 18, no. 9, pp. 1707-1719, Sept. 2016. 

% 1. Using Main_NLSI(file) to implement the non-local similarity based interpolation.

% 2. The input image is the ground-truth image which will be down-sampled first for interpolation, 
%     and the output image is the interpolated image.

% 3. The resolution of the input image is NxN and  the resolution of the output image is also NxN.

% 4.  If the input is the gray-level image, the output is also the gray-level image, where the PSNR should be calculated              with the double-format data.

% 5. If the input is the RGB color image, the output is also the RGB color image, where  the PSNR should be calculated             based on  the average PSNR value of three color channels.

% 6. Example: Main_NLSI('Lena.bmp') 