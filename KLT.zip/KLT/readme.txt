
%   This code is offered only for reserch purpose.
%   If you use this code for a potential publication, please cite the following paper:
% 
%   S. Y. Zhu, S-K Au Yeung and B. Zeng, 
%��R-D performance upper bound of transform coding for 2-D directional sources,��
%   IEEE Signal Processing Letters, vol. 16, no. 10, pp.861-864, Oct. 2009.


% input�� [1]N
%              [2]rho
%              [3]eta
%              [4]theta

% output: an (N^2)x(N^2) non-separable directional transform 

% Demo: for an NxN block

% N=8, rho=0.95, eta=5, theta=pi/4;
% T_KLT = KLT_mtx(N,rho,eta,theta);
